const utils = require('./utils');const path = require('./path');const constants = require('./constant');const mta = require('./mta/index');const cgi = require('./cgi');module.exports = {
  isAppScene() {
    if (!utils.canIUse('getLaunchOptionsSync')) {
      return false;
    }

    const { scene } = wx.getLaunchOptionsSync();

    return `${scene}` === '1168';
  },

  getLctMpOptions(options) {
    let {
      pageType = '',
      query = {},
      from = '',
    } = options;

    // if (!this.isAppScene()) {
    //   return Promise.reject('scene场景值不对，不在app场景下');
    // }

    if (!utils.compareVersion('2.18.1')) {
      return Promise.reject('当前小程序基础库低于2.18.1，不满足该插件所要求的最低版本');
    }

    if (!utils.isJumpPageType(pageType)) {
      return Promise.reject('pageType类型不对，请参考readme中对应的页面类型要求');
    }

    if (!from) {
      return Promise.reject('机构小程序appid缺失，请检查一下from是否有值！');
    }

    const {done, error} = utils.checkQuery(pageType, query);

    if (!done) {
      return Promise.reject(error);
    }

    const url = path.getPagePath(pageType, query, from);

    return Promise.resolve({
      appId: constants.LCT_APPID,
      path: `${constants.WEBVIEW_PATH}?cancel_double_skip=1&url=${encodeURIComponent(url)}`,
    });
  },

  LCT_PAGE: {
    FUND: constants.FUND,
    ETF: constants.ETF,
    INDUSTRY: constants.INDUSTRY,
    TOPIC: constants.TOPIC,
    DISCUSSION: constants.DISCUSSION,
  },

  sendPgv(options = {}) {
    const {openId, appId} = options;

    if (!openId) {
      console.error('openId没传入.');
      return;
    }

    if (!appId) {
      console.error('appid没传入.');
      return;
    }

    const channelAppid = this.isAppScene() ? 'wxd3678b66f965df4a' : 'wxcc8a51267886fec4';

    const params = mta.getParams(openId, appId, channelAppid);

    return new Promise((resove, reject) => {
      mta.report({
        params: params,
        success(data) {
          resove(data);
        },
        fail(err){
          reject(err);
        },
      });
    })
  },

  bindLctAccount(options = {}) {
    if (!options.appid) {
      return Promise.reject('appid没输入');
    }

    if (!options.openId) {
      return Promise.reject('openId没输入');
    }

    if (!options.token) {
      return Promise.reject('token没输入');
    }

    if (!options.unique) {
      return Promise.reject('unique没输入');
    }

    return new Promise((resolve, reject) => {
      cgi.requestLctAccount({
        data: {
          third_app_id: options.appid,
          third_openid: options.openId,
          authorize_token: options.token,
          legality_token: options.unique,
        },
        success(data) {
          resolve(data);
        },
        fail(data) {
          reject(data);
        }
      })
    });
  },

  clickMta(options) {
    const { SUBSCRIBE, UNSUBSCRIBE } = constants.MTA_KEY;
    const keys = [ SUBSCRIBE, UNSUBSCRIBE ];

    if (keys.indexOf(options.key) === -1) {
      return Promise.reject('key值没填');
    }

    if (!options.appid) {
      return Promise.reject('appid没输入.');
    }

    if (!options.openId) {
      return Promise.reject('openId没输入');
    }

    const channelAppid = this.isAppScene() ? 'wxd3678b66f965df4a' : 'wxcc8a51267886fec4';

    const params = mta.getParams(
        options.appid,
        options.openId,
        channelAppid,
        options.OChannel,
    );

    return new Promise((resolve, reject) => {
      mta.report({
        key: options.key,
        params: params,
        success(data) {
          resolve(data);
        },
        fail(err){
          reject(err);
        },
      });
    })
  },

  subscribe(options = {}) {
    const params = Object.assign({}, options, {
      key: constants.MTA_KEY.SUBSCRIBE,
    });

    return this.clickMta(params);
  },

  unsubscribe(options = {}) {
    const params = Object.assign({}, options, {
      key: constants.MTA_KEY.UNSUBSCRIBE,
    });

    return this.clickMta(params);
  }
}