const constants = require('./constant');module.exports = {
    getPagePath(page, query, from) {
        let path = '';
        let host = '';
        switch (page) {
            case constants.FUND:
                path = constants.FUND_PATH;
                host = constants.TX_FUND_DOMAIN;
                break;
            case constants.ETF:
                path = constants.ETF_PATH;
                host = constants.TX_FUND_DOMAIN;
                break;
            case constants.INDUSTRY:
                path = constants.INDUSTRY_PATH;
                host = constants.TX_FUND_DOMAIN;
                break;
            case constants.TOPIC:
                path = constants.TOPIC_PATH;
                host = constants.TX_TWM_DOMAIN;
                break;
            case constants.DISCUSSION:
                path = constants.DISCUSSION_PATH;
                host = constants.TX_TWM_DOMAIN;
                break;
        }

        let queryStr = '?lctfrom=jg_xcx';

        if (from) {
            queryStr = `${queryStr}&from_dtl=${from}`;
        }

        Object.keys(query).forEach((key, index) => {
            const realKey = constants.QUERY_MAP[key];

            queryStr = `${queryStr}&${realKey}=${query[key]}`;
        });

        return `${host}${path}${queryStr}`;
    },
}