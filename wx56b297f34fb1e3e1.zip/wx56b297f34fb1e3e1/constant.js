module.exports = {
    FUND: 'fund',

    ETF: 'etf',

    INDUSTRY: 'industry',

    TOPIC: 'topic',

    DISCUSSION: 'discussion',

    LCT_APPID: 'wxcc8a51267886fec4',

    WEBVIEW_PATH: 'pages/webview/index2',

    FUND_PATH: '/h5/v6/pages/product/detail/index',

    ETF_PATH: '/mb/v5/fund/list/etfproduct/etf_detail.shtml',

    INDUSTRY_PATH: '/mb/v5/fund/industry/optimistic_industry_normal.shtml',

    TOPIC_PATH: '/h5/v6/pages/discussion/main/topic/index',

    DISCUSSION_PATH: '/h5/v6/pages/discussion/main/stock/index',

    TX_FUND_DOMAIN: 'https://www.txfund.com',

    TX_TWM_DOMAIN: 'https://www.tencentwm.com',

    QUERY_MAP: {
        fundCode: 'fund_code',
        spid: 'spid',
        eftId: 'index_id',
        indId: 'industryid',
        topicId: 'topic_id',
        discussionId: 'stock_id'
    },

    MTA_KEY: {
        SUBSCRIBE: 'public.jg_xcx.subscribe',
        UNSUBSCRIBE: 'public.jg_xcx.unsubscribe',
    }
}