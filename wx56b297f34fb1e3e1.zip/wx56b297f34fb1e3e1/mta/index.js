module.exports = {
    getParams(openId, appid, channelAppid, OChannel) {
        const date = this.getDate();

        return {
            fch_fm: '',
            fch_i: '',
            fch_o: OChannel || '',
            fsvr_time: date,
            ftime: date,
            fuin: `${openId}@jg.tenpay.com`,
            // fuin: '085e9858e98d7174eaf9205d5@wx.tenpay.com',
            fuser_id: '',
            appid: channelAppid,
            page_key: `/jg/index-${Date.now()}`,
            up_type: 'mp',
            fpath: '/jg/index',
            fpt: 'wx',
            fos: 'ios',
            evt: 'brow',
            fsskey: openId,
            fidx: '10001',
            fu_v: '6.0',
            evt_p: 'onvision',
            ffrom: 'jg_xcx',
            scn: 1,
            from_dtl: appid,
        }
    },

    getDate() {
        const obj = new Date();
        const year = obj.getFullYear();
        const month = obj.getMonth() + 1;
        const date = obj.getDate();
        const hour = obj.getHours();
        const min = obj.getMinutes();
        const sec = obj.getSeconds();
        const ms = obj.getMilliseconds();

        return `${year}${month}${date}${hour}${min}${sec}${ms}`;
    },

    getUrl(params, key) {
        const mtaData = {
            url: key ? key : 'public.jg_xcx.show',
            dm: 'taclick',
            r2: '500701052',
            _: parseInt(String(Math.random() * 100000000), 10), // 防止浏览器缓存
            r5: encodeURIComponent(JSON.stringify(params)),
        };
        const url = 'https://www.tencentwm.com/webview/pingd?';
        const urlParams = Object.keys(mtaData).map(mtakey => `${mtakey}=${mtaData[mtakey]}`);
        return `${url}${urlParams.join('&')}`;
    },

    report(options) {
        const url = this.getUrl(options.params, options.key);

        wx.request({
            url: url,
            method: 'GET',
            success: options.success,
            fail: options.fail
        });
    }
}