const plugin = require('../index');Page({
  data: {},
  onLoad() {
    console.log('This is a plugin page!')
  },
  demo1() {
    // plugin.demo();
  }
})