module.exports = {
    requestLctAccount(options) {
        const url = 'https://www.tencentwm.com/fbp/fund/v1/trpc.com.tencent.fit.fuapl.open.toolbox.ao.facade.FuaplOpenToolboxAoService.ThirdBind';

        wx.request({
            url,
            method: 'POST',
            data: options.data,
            success: options.success,
            fail: options.fail
        });
    }
}