const constants = require('./constant');module.exports = {
    canIUse(method) {
        if (!wx) {
            return false;
        }

        return typeof wx[method] === 'function';
    },

    compareVersion(targetVersion) {
        if (!this.canIUse('getSystemInfoSync')) {
            return false;
        }

        const { SDKVersion = '0.0.0' } = wx.getSystemInfoSync();

        const [tarMajor, tarMinor, tarPatch] = targetVersion.split('.').map(val => parseFloat(val));
        const [curMajor, curMinor, curPatch] = SDKVersion.split('.').map(val => parseFloat(val));

        if (tarMajor === curMajor) {
            if (tarMinor === curMinor) {
                return curPatch >= tarPatch;
            }

            return curMinor > tarMinor;
        }

        return curMajor > tarMajor;
    },

    isJumpPageType(page) {
        return [
            constants.FUND,
            constants.ETF,
            constants.INDUSTRY,
            constants.TOPIC,
            constants.DISCUSSION,
        ].indexOf(page) !== -1;
    },

    checkQuery(page, query) {
        let done;

        switch (page) {
            case constants.FUND:
                done = query.fundCode && query.spid && true;
                return {
                    done,
                    error: done ? '' : '基金参数缺失，请检查一下query是否有fundCode和spid',
                }
            case constants.ETF:
                done = query.eftId && true;
                return {
                    done,
                    error: done ? '' : '指数参数缺失，请检查一下query是否有indexId',
                }
            case constants.INDUSTRY:
                done = query.indId && true;
                return {
                    done,
                    error: done ? '' : '行情参数缺失，请检查一下query是否有industryId',
                }
            case constants.TOPIC:
                done = query.topicId && true;
                return {
                    done,
                    error: done ? '' : '话题参数缺失，请检查一下query是否有topicId'
                }
            case constants.DISCUSSION:
                done = query.discussionId && true;
                return {
                    done,
                    error: done ? '' : '讨论区参数缺失，请检查一下query是否有discussionId',
                }
        }
    }
}